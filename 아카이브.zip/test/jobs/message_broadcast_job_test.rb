require 'test_helper'

class MessageBroadcastJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
